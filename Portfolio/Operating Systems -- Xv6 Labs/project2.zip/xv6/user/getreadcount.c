#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

//Vince Bengco
//CS 370 
//Project 2


int count;

int main()
{
	count = getreadcount();		//System Call that we made
	printf("Read Count: %d\n",count);
	exit(0);
}
