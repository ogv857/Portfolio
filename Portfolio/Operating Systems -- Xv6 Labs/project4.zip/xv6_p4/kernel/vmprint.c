// --------------------------------------------

#define PXROOTLEVEL     2

void
vmprint(pagetable_t pagetable)
{
  static int level = 2;
  static int rootdirectory = 1;
  if(rootdirectory)
    printf("page table %p\n", pagetable);

  for(int i = 0; i < 512; i++){
    pte_t pte = pagetable[i];
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
      uint64 child = PTE2PA(pte);
      for(int j = PXROOTLEVEL; j > level; j--)
        printf(".. ");
      printf("..%d: pte %p pa %p\n", i, pte, child);
      level--;
      rootdirectory = 0;
      vmprint((pagetable_t) child);
    } else if(pte & PTE_V){
      level = 0;
      for(int j = PXROOTLEVEL; j > level; j--)
        printf(".. ");
      printf("..%d: pte %p pa %p\n", i, pte, PTE2PA(pte));
      level = PXROOTLEVEL;
    }
  }
}

